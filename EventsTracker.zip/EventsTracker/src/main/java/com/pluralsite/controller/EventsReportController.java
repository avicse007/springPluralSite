package com.pluralsite.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pluralsite.model.Event;

@RestController
public class EventsReportController {

	@RequestMapping("/events")
	public List<Event> getEvents(){
		List<Event> events = new ArrayList<>();
		
		Event event1 = new Event();
		event1.setName("Angular JS User Group");
		
		Event event2 = new Event();
		event2.setName("Java User Group");
		
		Event event3 = new Event();
		event3.setName("JavaScript User Group");
		
		Event event4 = new Event();
		event4.setName("React Js User Group");
		
		Event event5 = new Event();
		event5.setName("Node Js User Group");
		
		events.add(event1);
		events.add(event2);
		events.add(event3);
		events.add(event4);
		events.add(event5);
		return events;
	}
}
